(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"counttothree_atlas_", frames: [[1820,199,71,153],[1893,199,71,153],[1966,199,71,153],[1807,354,71,153],[1443,0,56,153],[1244,0,197,197],[1880,354,56,153],[1820,0,197,197],[1504,0,314,314],[1938,354,56,118],[514,307,314,314],[1146,423,56,118],[830,307,314,314],[1996,354,32,118],[514,205,988,100],[1146,316,659,105],[514,0,728,203],[0,0,512,512]]}
];


// symbols:



(lib.CachedBmp_18 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.speakerfilledaudiotool = function() {
	this.initialize(ss["counttothree_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_16();
	this.instance.setTransform(22.7,0,0.4371,0.4371);

	this.instance_1 = new lib.CachedBmp_15();
	this.instance_1.setTransform(0,0,0.4371,0.4371);

	this.instance_2 = new lib.CachedBmp_18();
	this.instance_2.setTransform(22.7,0,0.4371,0.4371);

	this.instance_3 = new lib.CachedBmp_17();
	this.instance_3.setTransform(0,0,0.4371,0.4371);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,86.1,86.1);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_11();
	this.instance.setTransform(23.5,0,0.4371,0.4371);

	this.instance_1 = new lib.CachedBmp_15();
	this.instance_1.setTransform(0,0,0.4371,0.4371);

	this.instance_2 = new lib.CachedBmp_13();
	this.instance_2.setTransform(23.5,0,0.4371,0.4371);

	this.instance_3 = new lib.CachedBmp_17();
	this.instance_3.setTransform(0,0,0.4371,0.4371);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,86.1,86.1);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_7();
	this.instance.setTransform(27.05,0,0.4371,0.4371);

	this.instance_1 = new lib.CachedBmp_15();
	this.instance_1.setTransform(0,0,0.4371,0.4371);

	this.instance_2 = new lib.CachedBmp_9();
	this.instance_2.setTransform(27.05,0,0.4371,0.4371);

	this.instance_3 = new lib.CachedBmp_17();
	this.instance_3.setTransform(0,0,0.4371,0.4371);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,86.1,86.1);


(lib.speech1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("countthecircle");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// Button
	this.instance = new lib.speakerfilledaudiotool();
	this.instance.setTransform(0,0,0.043,0.043);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,22,22);


(lib.howmanycircles = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("howmanycirclesarethere");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// Layer_1
	this.instance = new lib.speakerfilledaudiotool();
	this.instance.setTransform(0,0,0.043,0.043);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,22,22);


(lib.circle3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("three");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// 3 number
	this.instance = new lib.CachedBmp_27();
	this.instance.setTransform(14.6,6.15,0.2613,0.2613);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).wait(2));

	// Layer_1
	this.instance_1 = new lib.CachedBmp_26();
	this.instance_1.setTransform(0,0,0.2613,0.2613);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,82.1,82.1);


(lib.circle2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("two");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// 2 number
	this.instance = new lib.CachedBmp_24();
	this.instance.setTransform(14.6,6.15,0.2613,0.2613);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).wait(2));

	// Layer_1
	this.instance_1 = new lib.CachedBmp_25();
	this.instance_1.setTransform(0,0,0.2613,0.2613);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,82.1,82.1);


(lib.circle1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("one");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// 1 number
	this.instance = new lib.CachedBmp_22();
	this.instance.setTransform(17.2,6.2,0.2613,0.2613);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).wait(2));

	// Layer_1
	this.instance_1 = new lib.CachedBmp_23();
	this.instance_1.setTransform(0,0,0.2613,0.2613);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,82.1,82.1);


// stage content:
(lib.counttothree = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
		
		
		
		/* Click to Go to Frame and Stop
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		
		this.buttonthree.addEventListener("click", fl_ClickToGoToAndStopAtFrame_8.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_8()
		{
			this.gotoAndStop(4);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5));

	// Layer_2
	this.instance = new lib.CachedBmp_14();
	this.instance.setTransform(134.05,181.95,0.5,0.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(4));

	// Layer_1
	this.instance_1 = new lib.circle3();
	this.instance_1.setTransform(479.05,184.55,1.9134,1.9134,0,0,0,41.2,41.2);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.circle3(), 3);

	this.instance_2 = new lib.circle2();
	this.instance_2.setTransform(304.6,184.55,1.9134,1.9134,0,0,0,41.2,41.2);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.circle2(), 3);

	this.instance_3 = new lib.circle1();
	this.instance_3.setTransform(129.05,184.55,1.9134,1.9134,0,0,0,41.2,41.2);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.circle1(), 3);

	this.instance_4 = new lib.howmanycircles();
	this.instance_4.setTransform(33.15,322.8,2.9877,2.99,0,0,0,11.1,11);
	new cjs.ButtonHelper(this.instance_4, 0, 1, 2, false, new lib.howmanycircles(), 3);

	this.instance_5 = new lib.speech1();
	this.instance_5.setTransform(0.6,0.3,2.989,2.989,0,0,0,0.2,0.1);
	new cjs.ButtonHelper(this.instance_5, 0, 1, 2, false, new lib.speech1(), 3);

	this.buttonthree = new lib.Symbol3();
	this.buttonthree.name = "buttonthree";
	this.buttonthree.setTransform(272.35,431,1.144,1.144,0,0,0,43.2,43.2);
	new cjs.ButtonHelper(this.buttonthree, 0, 1, 2);

	this.instance_6 = new lib.Symbol2();
	this.instance_6.setTransform(161.5,431,1.144,1.144,0,0,0,43.2,43.2);
	new cjs.ButtonHelper(this.instance_6, 0, 1, 2);

	this.instance_7 = new lib.Symbol1();
	this.instance_7.setTransform(49.3,431,1.144,1.144,0,0,0,43.1,43.2);
	new cjs.ButtonHelper(this.instance_7, 0, 1, 2);

	this.instance_8 = new lib.CachedBmp_5();
	this.instance_8.setTransform(126,289.3,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_2();
	this.instance_9.setTransform(126.7,29.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.buttonthree},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).to({state:[]},1).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(320,240,300,240.10000000000002);
// library properties:
lib.properties = {
	id: '9FFA8D284D4F4BF784593171C5D97167',
	width: 640,
	height: 480,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/counttothree_atlas_.png", id:"counttothree_atlas_"},
		{src:"sounds/countthecircle.mp3", id:"countthecircle"},
		{src:"sounds/howmanycirclesarethere.mp3", id:"howmanycirclesarethere"},
		{src:"sounds/one.mp3", id:"one"},
		{src:"sounds/three.mp3", id:"three"},
		{src:"sounds/two.mp3", id:"two"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['9FFA8D284D4F4BF784593171C5D97167'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;